La seguente cartella contiene tutti gli appunti di sistemi operativi presi dalle slide di Staiano e altre fonti.

Indice:

- [[shell]]
- [[File I-O]]
- [[File System]]

