L'index-node è una struttura di controllo associata ad ogni file. Molti nomi dei file possono essere associati con lo stesso i-node.
![[Pasted image 20250305163851.png]]