![[Pasted image 20250305162149.png]]

Queste system call troncano un file esistente a length byte. Se il file ha una dimensione maggiore a length i dati oltre length non sono piu accessibili. Se il file ha meno di lenght byte il comportamento della funzione dipende dall'implementazione.