![[Pasted image 20250304170536.png]]
La system call close permette di chiudere un file. Quando un processo termina, tutti i file aperti vengono automaticamente chiusi.