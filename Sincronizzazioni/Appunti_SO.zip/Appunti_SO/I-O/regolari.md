#fileI-O
I tipi di file regolari sono file di testo o che comunque non rappresentano dati in nessuna struttura particolare e possono essere visti come un flusso di bit.