#fileI-O
Sono file che contengono nomi di altri file con puntatori alle informazioni su tali file