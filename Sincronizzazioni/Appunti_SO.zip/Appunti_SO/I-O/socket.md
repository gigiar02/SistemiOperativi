#fileI-O
Sono file che servono per la comunicazione tra processi su rete.