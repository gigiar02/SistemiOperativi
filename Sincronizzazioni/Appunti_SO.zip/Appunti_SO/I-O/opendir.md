#fileI-O 

Una directory può essere letta da chiunque abbia i permessi di accesso per lettura. I permessi di esecuzione e scrittura per una directory determinano se si possono creare nuovi file nella directory e se si possono cancellare.
![[Pasted image 20250305164921.png]]
![[Pasted image 20250305164933.png]]
