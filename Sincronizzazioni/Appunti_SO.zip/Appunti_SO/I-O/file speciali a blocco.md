#fileI-O
i file speciali a blocco sono file nei quali i dati sono ordinati in blocchi a indirizzamento casuale.