#fileI-O
I file di tipo FIFO sono utilizzati per la comunicazione tra processi