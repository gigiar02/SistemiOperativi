#fileI-O 
è possibile far puntare piu directory all'inode di un file. Il modo per creare un hard link ad un file esistente è quella di usare la funzione link.
![[Pasted image 20250305164127.png]]
![[Pasted image 20250305164201.png]]
