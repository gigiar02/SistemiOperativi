#fileI-O 

![[Pasted image 20250305160214.png]]

Queste funzioni permettono di cambiare i permessi di accesso ad un file. Restituiscono 0 se va a buon altrimenti -1. Per cambiare i permessi di un file l'effective user ID del processo deve essere uguala all'id del proprietario oppure il processo deve avere i diritti del superutente.