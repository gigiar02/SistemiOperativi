#fileI-O
Servono per rappresentare dispositivi che sono formati da flussi di caratteri.