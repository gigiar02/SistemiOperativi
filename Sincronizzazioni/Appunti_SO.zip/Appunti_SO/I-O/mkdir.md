#fileI-O 

![[Pasted image 20250305164623.png]]
Queste funzioni permettono di creare directory e rimuoverle se vuote.
