#fileI-O 

Per rimuovere un elemento dalla tabella della directory si utilizza la funzione unlink.
![[Pasted image 20250305164248.png]]
La funzione decrementa il numero di link del file puntato da pathname. Il file risulta ancora accessibile se il numero di link è non nullo.
