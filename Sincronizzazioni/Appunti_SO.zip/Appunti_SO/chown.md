![[Pasted image 20250305161541.png]]
Queste funzioni permettono di cambiare user ID e il group ID di un file.
![[Pasted image 20250305161705.png]]
