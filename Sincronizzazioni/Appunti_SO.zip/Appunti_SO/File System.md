Un file system è sistema di file gerarchico. Ogni partizione di un hard disk può contenere un file system.
![[Pasted image 20250305163538.png]]
![[Pasted image 20250305163614.png]]
Ogni file ha un [[I-node]]

