#processo
Alloca un numero specifico di byte di memoria.