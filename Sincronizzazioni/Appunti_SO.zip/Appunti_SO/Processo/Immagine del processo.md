#processo
L'immagine di un processo è l'insieme delle aree di memoria e delle strutture dati allocate al processo. Non tutta l'immagine è accessibile dall'utente e infatti vi è una parte accessibile solo dall'utente e un'altra dal kernel.
![[Pasted image 20250321160411.png]]
Quando un processo viene swappato non tutta la sua immagine può essere swappata in memoria.
![[Pasted image 20250321160528.png]]
