#processo
Alloca spazio per uno specifico numero di oggetti di dimensione specificata.