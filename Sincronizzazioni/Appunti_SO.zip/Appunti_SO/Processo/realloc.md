#processo
Incrementa o decrementa la dimensione di'un area di memoria allocata in precedenza