#processo
Quando viene creato un processo figlio questo inizialmente condivide i dati del padre. Qu
è una tecnica secondo la quale viene effettivamente copiata una pagina di memoria per il nuovo processo soltanto quando ci viene effettuata una scrittura.
Ciò rende piu efficiente il meccanismo di creazione di un processo.