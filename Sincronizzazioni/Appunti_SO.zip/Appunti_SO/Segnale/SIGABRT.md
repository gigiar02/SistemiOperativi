#segnale 
Permette di terminare un processo in modo anormale