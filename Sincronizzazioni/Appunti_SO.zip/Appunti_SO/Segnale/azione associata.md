#segnale
L'azione associata è l'azione che deve essere intrapresa dal kernel quando si verifica un [[segnale]]. Nel tempo che intercorre tra la generazione del segnale e la sua consegna(esecuzione delle azioni specificate) si dice che il segnale è pendente.
