#segnale 
[[segnale]] generato quando il terminale viene chiuso