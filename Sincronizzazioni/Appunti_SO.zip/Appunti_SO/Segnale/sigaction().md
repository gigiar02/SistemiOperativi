#segnale 
![[Pasted image 20250324161522.png]]
Permette di specificare una maschera dei segnali da utilizzare quando è eseguito il gestore dei segnali passato in input.
- signo è il numero del segnale la cui azione stiamo esaminando o modificando.
- act: se è non nullo, stiamo modificando l'azione
- oact: se è non nullo ritorna l'azione precedente per il segnale attraverso il puntatore act
![[Pasted image 20250324161847.png]]

Slide 66 lezione segnali(non capita)
![[Pasted image 20250324162924.png]]