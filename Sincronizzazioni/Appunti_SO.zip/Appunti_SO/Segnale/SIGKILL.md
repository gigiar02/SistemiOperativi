#segnale 
Quando un processo riceve questo segnale verrà sicuramente terminato. Infatti questo segnale non può essere ignorato o intercettato.