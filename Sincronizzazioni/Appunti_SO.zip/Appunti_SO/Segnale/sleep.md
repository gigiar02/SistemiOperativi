#segnale 
![[Pasted image 20250324114733.png]]
Sospende il processo chiamante fino a quanto non trascorrono seconds secondi. Restituisce il tempo effettivo che ci ha messo a ritornare poiché potrebbe non essere quello che ci si aspettava per via di altre attività del sistema.