#segnale 
Cosi come SIGUSR2 sono segnali definiti dall'utente  per i programmi.