#segnale 
![[Pasted image 20250324115717.png]]

Invia il segnale [[SIGABRT]] al chiamante.