#processo 

![[Pasted image 20250322083308.png]]
La funzione execve esegue il file indicato da filename passandogli in inputi gli argomenti passati da argv e le variabili d'ambiente prese da envp. Entrambe le liste in input devon essere terminate da un puntatore nullo.