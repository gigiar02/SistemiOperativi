#segnale 
[[segnale]] di allarme utilizzato per notificare il processo che un timer è finito