#segnale 

[[segnale]] che viene generato quando si generea un'eccezione a livello hardware.