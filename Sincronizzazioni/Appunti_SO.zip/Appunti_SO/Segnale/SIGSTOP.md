#segnale 
[[segnale]] che permette di stoppare un processo. Non può essere catturato o ignorato.