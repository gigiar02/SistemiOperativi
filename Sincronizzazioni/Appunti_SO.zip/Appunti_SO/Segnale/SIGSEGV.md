#segnale  
"Segmentation Violation"
[[segnale]] che viene generato quando il processo effettua un accesso in memoria illegale.