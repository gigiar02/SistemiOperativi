#segnale 
[[segnale]] generato quando si digita una combinazione di tasti da terminale. Ad esempio si può generare questo segnale attraverso  CTR+C che va a bloccare l'esecuzione del processo.