#segnale 
![[Pasted image 20250324113402.png]]
Permette al kernel di inviare un segnale [[SIGALRM]] al processo invocante dopo seconds secondi.
Se seconds è 0 non viene creato nessun alarm e quello precedente viene cancellato(sovrascritto)
