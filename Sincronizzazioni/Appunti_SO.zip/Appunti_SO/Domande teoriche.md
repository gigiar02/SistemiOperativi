1) Domanda teorica: Parla dei problemi P e NP e dimostra perché P è contenuto impropriamente in NP (nell'altro compito era di dimostrare P = NP o così mi hanno detto.)




2) Domanda teorica: Descrivere la Macchina di Turing ed i suoi stati accettanti.


3) Definire cosa sono i problemi NP completi e dimostare che se un problema NP completo non è risolvibile in tempo polinomiale allora tutti gli altri problemi non sono risolvibili in tempo polinomiale

