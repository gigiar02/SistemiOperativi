![[Pasted image 20250304172433.png]]
Scrive nel file con descrittore fildes, nbytes byte da buf, a partire dalla posizione corrente. Aggiorna la posizione corrente. Restituisce il numero di byte effettivamente scritti o -1 in caso di errore.
![[Pasted image 20250304172626.png]]![[Pasted image 20250304172639.png]]
