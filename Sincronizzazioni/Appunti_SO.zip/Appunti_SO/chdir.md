![[Pasted image 20250305164958.png]]
Ciascun processo è dotato di una directory di lavoro corrente da cui partono tutti i path relativi. Per sapere la directory corrente si usa getcwd. Per cambiare la directory di lavoro corrente di un processo si usa la funzione chdir.
![[Pasted image 20250305165240.png]]![[Pasted image 20250305165316.png]]

ESERCIZI:
![[Pasted image 20250305165335.png]]

![[Pasted image 20250305165348.png]]

![[Pasted image 20250305165359.png]]