#shell 

![[Pasted image 20250321170311.png]]
