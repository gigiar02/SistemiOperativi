#shell 
![[Pasted image 20250321170234.png]]
