#shell 
Utilizza come prompt di default il "%". Rispetto alla [[shell Bourne]] introduce nuove funzionalità come:
- Completamento automatico di comandi
- controllo dei job
- aritmetica built-in.
Questa shell è preferita per l'utilizzo interattivo alla shell Bourne mentre è preferita la shell Bourne per lo scripting, poiché gli script sono piu semplici e veloci.