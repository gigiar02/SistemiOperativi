#shell 
è una shell semplice veloce e compatta, il cui prompt di default è il "$"