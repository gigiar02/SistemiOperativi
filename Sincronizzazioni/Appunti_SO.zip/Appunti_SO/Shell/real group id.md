#shell 
Identifica il gruppo che ha eseguito il processo
![[Pasted image 20250321170256.png]]
