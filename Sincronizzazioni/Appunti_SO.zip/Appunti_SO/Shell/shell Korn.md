#shell 
Utilizza come prompt il "$" e rispetto alle precedenti introduce caratteristiche aggiuntive come:
- alias
- funzioni
- wildcard per espressioni regolari
- aritmetica built in
- controllo dei job etc..