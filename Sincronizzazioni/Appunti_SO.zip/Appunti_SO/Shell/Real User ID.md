#shell 
Identifica l'utente che ha eseguito il processo
![[Pasted image 20250321170220.png]]
