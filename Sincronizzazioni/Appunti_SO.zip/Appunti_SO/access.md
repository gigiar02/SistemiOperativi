![[Pasted image 20250305153226.png]]
 Effettua il test di accessibilità di un file sulla base del real user ID o del real Group ID.
 A mode si può passare:
 - F_OK per verificare se il file esiste
 - R_OK,W_OK,X_OK
 Restituisce 0 se ok, altrimenti -1.

![[Pasted image 20250305153556.png]]
![[Pasted image 20250305153609.png]]
